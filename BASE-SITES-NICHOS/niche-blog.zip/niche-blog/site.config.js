// ============================================================
// CONFIGURAÇÃO CENTRAL DO BLOG
// Edite este arquivo para personalizar seu blog de nicho
// ============================================================

const siteConfig = {
  // --- IDENTIDADE DO BLOG ---
  name: "FinançasPro",
  tagline: "Inteligência financeira para quem quer resultados reais",
  description:
    "Dicas práticas de finanças pessoais, investimentos e renda extra para brasileiros que querem conquistar independência financeira.",
  url: "https://seu-dominio.com.br", // ← MUDE AQUI
  locale: "pt_BR",
  language: "pt-BR",

  // --- NICHO ---
  // Exemplos: "finanças pessoais", "saúde e bem-estar", "produtividade",
  //           "culinária", "desenvolvimento pessoal", "tecnologia", "pets"
  niche: "finanças pessoais e investimentos",

  // Palavras-chave principais do nicho (usadas na geração de artigos)
  keywords: [
    "finanças pessoais",
    "investimentos",
    "renda extra",
    "independência financeira",
    "tesouro direto",
    "fundos imobiliários",
    "controle financeiro",
    "guardar dinheiro",
    "renda passiva",
    "planejamento financeiro",
  ],

  // --- AUTOR ---
  author: {
    name: "Equipe FinançasPro",
    bio: "Especialistas em educação financeira com foco no contexto brasileiro.",
    avatar: "/avatar.jpg", // coloque em /public/avatar.jpg
  },

  // --- AFILIADOS ---
  // Adicione seus links de afiliado aqui
  // O sistema vai inserir automaticamente nos artigos quando o contexto for relevante
  affiliates: [
    {
      id: "nubank",
      name: "Nubank",
      url: "https://nubank.com.br/?ref=SEU_CODIGO", // ← MUDE AQUI
      keywords: ["conta digital", "cartão sem anuidade", "banco digital"],
      cta: "Abra sua conta gratuita no Nubank",
    },
    {
      id: "xp",
      name: "XP Investimentos",
      url: "https://www.xpi.com.br/?ref=SEU_CODIGO", // ← MUDE AQUI
      keywords: ["investimentos", "corretora", "ações", "fundos", "tesouro direto"],
      cta: "Comece a investir com a XP",
    },
    {
      id: "rico",
      name: "Rico",
      url: "https://www.rico.com.vc/?ref=SEU_CODIGO", // ← MUDE AQUI
      keywords: ["investir", "fundos imobiliários", "renda fixa"],
      cta: "Abra sua conta na Rico gratuitamente",
    },
  ],

  // --- ADSENSE ---
  adsense: {
    enabled: true,
    publisherId: "ca-pub-XXXXXXXXXXXXXXXX", // ← MUDE AQUI após aprovação
    // Slots disponíveis (crie no painel do AdSense)
    slots: {
      header: "1234567890",
      inArticle: "0987654321",
      sidebar: "1122334455",
    },
  },

  // --- GERAÇÃO DE ARTIGOS ---
  generation: {
    // Quantos artigos gerar por execução do script
    articlesPerRun: 3,

    // Tom do conteúdo
    tone: "prático, direto e empático — como um amigo que entende de finanças",

    // Nível do público
    audienceLevel: "iniciante a intermediário",

    // Mínimo de palavras por artigo (artigos muito curtos são penalizados)
    minWords: 1200,

    // Categorias de artigos a gerar (rodízio automático)
    categories: [
      "Investimentos",
      "Renda Extra",
      "Controle Financeiro",
      "Independência Financeira",
      "Dicas Práticas",
    ],
  },

  // --- SEO ---
  seo: {
    twitterHandle: "@financaspro", // opcional
    ogImage: "/og-default.jpg", // coloque em /public/
    googleSiteVerification: "", // código do Google Search Console
  },

  // --- MENU DE NAVEGAÇÃO ---
  navigation: [
    { label: "Início", href: "/" },
    { label: "Investimentos", href: "/blog?categoria=Investimentos" },
    { label: "Renda Extra", href: "/blog?categoria=Renda+Extra" },
    { label: "Controle Financeiro", href: "/blog?categoria=Controle+Financeiro" },
    { label: "Sobre", href: "/sobre" },
  ],
};

module.exports = siteConfig;
